/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["../templates/**/*.html",
            "./src/**/*.js",
            "./templates/**/*.html",
            "./**/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}
